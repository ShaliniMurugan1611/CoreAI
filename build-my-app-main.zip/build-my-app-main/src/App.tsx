import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import AppLayout from "./components/AppLayout";
import Index from "./pages/Index";
import TextExplanation from "./pages/TextExplanation";
import CodeGeneration from "./pages/CodeGeneration";
import AudioLearning from "./pages/AudioLearning";
import ImageVisualization from "./pages/ImageVisualization";
import SettingsPage from "./pages/SettingsPage";
import About from "./pages/About";
import NotFound from "./pages/NotFound";

const queryClient = new QueryClient();

const App = () => (
  <QueryClientProvider client={queryClient}>
    <TooltipProvider>
      <Toaster />
      <Sonner />
      <BrowserRouter>
        <AppLayout>
          <Routes>
            <Route path="/" element={<Index />} />
            <Route path="/text-explanation" element={<TextExplanation />} />
            <Route path="/code-generation" element={<CodeGeneration />} />
            <Route path="/audio-learning" element={<AudioLearning />} />
            <Route path="/image-visualization" element={<ImageVisualization />} />
            <Route path="/settings" element={<SettingsPage />} />
            <Route path="/about" element={<About />} />
            <Route path="*" element={<NotFound />} />
          </Routes>
        </AppLayout>
      </BrowserRouter>
    </TooltipProvider>
  </QueryClientProvider>
);

export default App;
