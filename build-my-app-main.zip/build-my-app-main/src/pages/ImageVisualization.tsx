import { useState } from "react";
import { Image as ImageIcon, Loader2, Download } from "lucide-react";

const sampleDiagrams = [
  { title: "Neural Network Architecture", desc: "Layer-by-layer visualization" },
  { title: "Data Flow Diagram", desc: "Input to output pipeline" },
  { title: "Loss Function Landscape", desc: "3D optimization surface" },
];

const ImageVisualization = () => {
  const [topic, setTopic] = useState("");
  const [loading, setLoading] = useState(false);
  const [generated, setGenerated] = useState(false);

  const handleGenerate = () => {
    if (!topic.trim()) return;
    setLoading(true);
    setTimeout(() => {
      setGenerated(true);
      setLoading(false);
    }, 2500);
  };

  return (
    <div className="p-6 lg:p-10">
      <div className="mx-auto max-w-4xl">
        <div className="mb-8">
          <div className="mb-2 inline-flex items-center gap-2 rounded-full bg-warning/10 px-3 py-1 text-xs font-medium text-warning">
            <ImageIcon className="h-3.5 w-3.5" />
            Image Visualization
          </div>
          <h1 className="text-3xl font-bold text-foreground">Educational Diagram Generator</h1>
          <p className="mt-2 text-muted-foreground">
            Generate visual diagrams and architecture illustrations for ML concepts
          </p>
        </div>

        <div className="glass-card mb-8 rounded-xl p-6">
          <label className="mb-2 block text-sm font-medium text-foreground">ML Topic for Visualization</label>
          <input
            type="text"
            value={topic}
            onChange={(e) => setTopic(e.target.value)}
            placeholder="e.g., Convolutional Neural Network Architecture"
            className="mb-6 w-full rounded-lg border border-border bg-secondary/50 px-4 py-3 text-sm text-foreground placeholder:text-muted-foreground focus:border-primary focus:outline-none focus:ring-1 focus:ring-primary"
          />

          <button
            onClick={handleGenerate}
            disabled={!topic.trim() || loading}
            className="inline-flex items-center gap-2 rounded-lg bg-primary px-6 py-3 text-sm font-semibold text-primary-foreground transition-all hover:opacity-90 disabled:opacity-50 glow-hover"
          >
            {loading ? <Loader2 className="h-4 w-4 animate-spin" /> : <ImageIcon className="h-4 w-4" />}
            {loading ? "Generating Diagrams..." : "Generate Visualizations"}
          </button>
        </div>

        {generated && (
          <div className="space-y-6">
            <h2 className="text-lg font-semibold text-foreground">Generated Diagrams</h2>
            <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
              {sampleDiagrams.map((diagram, i) => (
                <div key={i} className="glass-card group rounded-xl overflow-hidden">
                  {/* Placeholder diagram */}
                  <div className="relative aspect-square bg-secondary/50 flex items-center justify-center">
                    <div className="text-center p-4">
                      <div className="mx-auto mb-3 flex h-16 w-16 items-center justify-center rounded-xl bg-primary/10">
                        <ImageIcon className="h-8 w-8 text-primary" />
                      </div>
                      <p className="text-xs text-muted-foreground">AI-Generated Diagram</p>
                    </div>
                    <div className="absolute inset-0 flex items-center justify-center bg-background/80 opacity-0 transition-opacity group-hover:opacity-100">
                      <button className="inline-flex items-center gap-1.5 rounded-lg bg-primary px-3 py-2 text-xs font-medium text-primary-foreground">
                        <Download className="h-3.5 w-3.5" /> Download
                      </button>
                    </div>
                  </div>
                  <div className="p-4">
                    <h3 className="text-sm font-semibold text-foreground">{diagram.title}</h3>
                    <p className="text-xs text-muted-foreground">{diagram.desc}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default ImageVisualization;
