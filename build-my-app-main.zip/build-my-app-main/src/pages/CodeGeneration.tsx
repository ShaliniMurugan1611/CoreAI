import { useState } from "react";
import { Code, Loader2, Copy, Check, Download } from "lucide-react";

const sampleCode = `import numpy as np
import matplotlib.pyplot as plt

class NeuralNetwork:
    """Simple Neural Network with Backpropagation from scratch."""
    
    def __init__(self, layers):
        """Initialize network with given layer sizes.
        
        Args:
            layers: List of integers representing neurons per layer
                    e.g., [2, 4, 1] = 2 inputs, 4 hidden, 1 output
        """
        self.weights = []
        self.biases = []
        
        # Initialize weights with Xavier initialization
        for i in range(len(layers) - 1):
            w = np.random.randn(layers[i], layers[i+1]) * np.sqrt(2.0 / layers[i])
            b = np.zeros((1, layers[i+1]))
            self.weights.append(w)
            self.biases.append(b)
    
    def sigmoid(self, z):
        """Sigmoid activation function."""
        return 1 / (1 + np.exp(-np.clip(z, -500, 500)))
    
    def sigmoid_derivative(self, z):
        """Derivative of sigmoid function."""
        s = self.sigmoid(z)
        return s * (1 - s)
    
    def forward(self, X):
        """Forward pass through the network."""
        self.activations = [X]
        self.z_values = []
        
        current = X
        for w, b in zip(self.weights, self.biases):
            z = np.dot(current, w) + b
            self.z_values.append(z)
            current = self.sigmoid(z)
            self.activations.append(current)
        
        return current
    
    def backward(self, X, y, learning_rate=0.1):
        """Backward pass - compute gradients and update weights."""
        m = X.shape[0]
        
        # Output layer error
        delta = (self.activations[-1] - y) * self.sigmoid_derivative(self.z_values[-1])
        
        # Backpropagate through layers
        for i in range(len(self.weights) - 1, -1, -1):
            dw = np.dot(self.activations[i].T, delta) / m
            db = np.sum(delta, axis=0, keepdims=True) / m
            
            if i > 0:
                delta = np.dot(delta, self.weights[i].T) * self.sigmoid_derivative(self.z_values[i-1])
            
            self.weights[i] -= learning_rate * dw
            self.biases[i] -= learning_rate * db
    
    def train(self, X, y, epochs=1000, learning_rate=0.1):
        """Train the network."""
        losses = []
        for epoch in range(epochs):
            output = self.forward(X)
            loss = np.mean((output - y) ** 2)
            losses.append(loss)
            self.backward(X, y, learning_rate)
            
            if epoch % 100 == 0:
                print(f"Epoch {epoch}, Loss: {loss:.6f}")
        
        return losses

# Example: XOR Problem
X = np.array([[0,0], [0,1], [1,0], [1,1]])
y = np.array([[0], [1], [1], [0]])

nn = NeuralNetwork([2, 4, 1])
losses = nn.train(X, y, epochs=5000, learning_rate=0.5)

# Test predictions
predictions = nn.forward(X)
print("\\nPredictions:")
for i in range(len(X)):
    print(f"  Input: {X[i]} -> Predicted: {predictions[i][0]:.4f}, Expected: {y[i][0]}")

# Plot training loss
plt.plot(losses)
plt.title("Training Loss Over Time")
plt.xlabel("Epoch")
plt.ylabel("MSE Loss")
plt.grid(True, alpha=0.3)
plt.show()`;

const CodeGeneration = () => {
  const [topic, setTopic] = useState("");
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState("");
  const [copied, setCopied] = useState(false);

  const handleGenerate = () => {
    if (!topic.trim()) return;
    setLoading(true);
    setTimeout(() => {
      setResult(sampleCode);
      setLoading(false);
    }, 2500);
  };

  const handleCopy = () => {
    navigator.clipboard.writeText(result);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleDownload = () => {
    const blob = new Blob([result], { type: "text/plain" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = "generated_code.py";
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="p-6 lg:p-10">
      <div className="mx-auto max-w-4xl">
        <div className="mb-8">
          <div className="mb-2 inline-flex items-center gap-2 rounded-full bg-accent/10 px-3 py-1 text-xs font-medium text-accent">
            <Code className="h-3.5 w-3.5" />
            Code Generation
          </div>
          <h1 className="text-3xl font-bold text-foreground">Python Code Generator</h1>
          <p className="mt-2 text-muted-foreground">
            Generate production-ready Python implementations for ML concepts
          </p>
        </div>

        <div className="glass-card mb-8 rounded-xl p-6">
          <label className="mb-2 block text-sm font-medium text-foreground">Describe what you want to implement</label>
          <input
            type="text"
            value={topic}
            onChange={(e) => setTopic(e.target.value)}
            placeholder="e.g., Neural network with backpropagation from scratch"
            className="mb-4 w-full rounded-lg border border-border bg-secondary/50 px-4 py-3 text-sm text-foreground placeholder:text-muted-foreground focus:border-primary focus:outline-none focus:ring-1 focus:ring-primary"
          />

          <div className="mb-6 rounded-lg bg-secondary/50 p-4">
            <p className="mb-2 text-xs font-medium text-muted-foreground">Detected Dependencies</p>
            <div className="flex flex-wrap gap-2">
              {["numpy", "matplotlib", "scikit-learn"].map((dep) => (
                <span key={dep} className="rounded-md bg-primary/10 px-2.5 py-1 text-xs font-mono text-primary">
                  {dep}
                </span>
              ))}
            </div>
          </div>

          <button
            onClick={handleGenerate}
            disabled={!topic.trim() || loading}
            className="inline-flex items-center gap-2 rounded-lg bg-primary px-6 py-3 text-sm font-semibold text-primary-foreground transition-all hover:opacity-90 disabled:opacity-50 glow-hover"
          >
            {loading ? <Loader2 className="h-4 w-4 animate-spin" /> : <Code className="h-4 w-4" />}
            {loading ? "Generating Code..." : "Generate Code"}
          </button>
        </div>

        {result && (
          <div className="glass-card rounded-xl overflow-hidden">
            <div className="flex items-center justify-between border-b border-border px-5 py-3">
              <div className="flex items-center gap-2">
                <div className="flex gap-1.5">
                  <div className="h-3 w-3 rounded-full bg-destructive/60" />
                  <div className="h-3 w-3 rounded-full bg-warning/60" />
                  <div className="h-3 w-3 rounded-full bg-success/60" />
                </div>
                <span className="ml-2 text-xs text-muted-foreground font-mono">generated_code.py</span>
              </div>
              <div className="flex gap-2">
                <button onClick={handleCopy} className="inline-flex items-center gap-1.5 rounded-md bg-secondary px-2.5 py-1 text-xs text-secondary-foreground hover:bg-muted">
                  {copied ? <Check className="h-3 w-3" /> : <Copy className="h-3 w-3" />}
                  {copied ? "Copied" : "Copy"}
                </button>
                <button onClick={handleDownload} className="inline-flex items-center gap-1.5 rounded-md bg-secondary px-2.5 py-1 text-xs text-secondary-foreground hover:bg-muted">
                  <Download className="h-3 w-3" /> Download
                </button>
              </div>
            </div>
            <pre className="overflow-x-auto p-5 text-sm leading-relaxed text-foreground/90 font-mono">
              <code>{result}</code>
            </pre>
          </div>
        )}
      </div>
    </div>
  );
};

export default CodeGeneration;
