import { Info, ExternalLink, Brain, Sparkles } from "lucide-react";

const techStack = [
  { name: "Google Gemini 2.0", desc: "Advanced AI for content generation" },
  { name: "Flask", desc: "Python backend framework" },
  { name: "gTTS", desc: "Text-to-speech engine" },
  { name: "Stable Diffusion", desc: "Image generation" },
  { name: "React", desc: "Frontend UI framework" },
  { name: "TailwindCSS", desc: "Utility-first styling" },
];

const About = () => {
  return (
    <div className="p-6 lg:p-10">
      <div className="mx-auto max-w-3xl">
        <div className="mb-8">
          <div className="mb-2 inline-flex items-center gap-2 rounded-full bg-info/10 px-3 py-1 text-xs font-medium text-info">
            <Info className="h-3.5 w-3.5" />
            About
          </div>
          <h1 className="text-3xl font-bold text-foreground">About GyanGuru</h1>
          <p className="mt-2 text-muted-foreground">
            AI-Powered Learning Assistant for AI & Machine Learning
          </p>
        </div>

        <div className="glass-card mb-6 rounded-xl p-6">
          <div className="mb-4 flex items-center gap-3">
            <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-primary/10">
              <Sparkles className="h-6 w-6 text-primary" />
            </div>
            <div>
              <h2 className="text-xl font-bold text-foreground">GyanGuru</h2>
              <p className="text-xs text-muted-foreground">SmartBridge Project</p>
            </div>
          </div>
          
          <p className="text-sm leading-relaxed text-muted-foreground">
            GyanGuru is a revolutionary AI-powered web application designed to transform how students,
            educators, and professionals learn Machine Learning concepts through multiple interactive
            modalities. It leverages Google's advanced Gemini 2.0 Flash AI models combined with
            text-to-speech, image generation, and code execution capabilities to provide a comprehensive,
            personalized learning experience.
          </p>
        </div>

        {/* Capabilities */}
        <div className="glass-card mb-6 rounded-xl p-6">
          <h2 className="mb-4 text-lg font-semibold text-foreground">Key Capabilities</h2>
          <div className="grid gap-3 sm:grid-cols-2">
            {[
              { title: "Text Explanations", desc: "Structured, markdown-formatted educational content" },
              { title: "Code Generation", desc: "Production-ready Python with dependency detection" },
              { title: "Audio Lessons", desc: "Conversational narration via text-to-speech" },
              { title: "Visual Diagrams", desc: "Technical illustrations and architecture charts" },
            ].map((cap) => (
              <div key={cap.title} className="rounded-lg bg-secondary/50 p-4">
                <h3 className="text-sm font-semibold text-foreground">{cap.title}</h3>
                <p className="text-xs text-muted-foreground">{cap.desc}</p>
              </div>
            ))}
          </div>
        </div>

        {/* Tech Stack */}
        <div className="glass-card rounded-xl p-6">
          <h2 className="mb-4 text-lg font-semibold text-foreground">Technology Stack</h2>
          <div className="grid gap-2 sm:grid-cols-2 lg:grid-cols-3">
            {techStack.map((tech) => (
              <div key={tech.name} className="flex items-center gap-3 rounded-lg bg-secondary/50 p-3">
                <Brain className="h-4 w-4 text-primary shrink-0" />
                <div>
                  <p className="text-sm font-medium text-foreground">{tech.name}</p>
                  <p className="text-xs text-muted-foreground">{tech.desc}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

export default About;
