import { useState } from "react";
import { Settings as SettingsIcon, Key, Save, Check } from "lucide-react";

const SettingsPage = () => {
  const [geminiKey, setGeminiKey] = useState("");
  const [hfKey, setHfKey] = useState("");
  const [saved, setSaved] = useState(false);

  const handleSave = () => {
    setSaved(true);
    setTimeout(() => setSaved(false), 2000);
  };

  return (
    <div className="p-6 lg:p-10">
      <div className="mx-auto max-w-2xl">
        <div className="mb-8">
          <div className="mb-2 inline-flex items-center gap-2 rounded-full bg-muted px-3 py-1 text-xs font-medium text-muted-foreground">
            <SettingsIcon className="h-3.5 w-3.5" />
            Settings
          </div>
          <h1 className="text-3xl font-bold text-foreground">Configuration</h1>
          <p className="mt-2 text-muted-foreground">
            Manage your API keys and application preferences
          </p>
        </div>

        <div className="glass-card rounded-xl p-6">
          <div className="mb-6 flex items-center gap-3">
            <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-primary/10">
              <Key className="h-5 w-5 text-primary" />
            </div>
            <div>
              <h2 className="text-base font-semibold text-foreground">API Keys</h2>
              <p className="text-xs text-muted-foreground">Required for AI content generation</p>
            </div>
          </div>

          <div className="space-y-4">
            <div>
              <label className="mb-1.5 block text-sm font-medium text-foreground">Google Gemini API Key</label>
              <input
                type="password"
                value={geminiKey}
                onChange={(e) => setGeminiKey(e.target.value)}
                placeholder="Enter your Gemini API key"
                className="w-full rounded-lg border border-border bg-secondary/50 px-4 py-3 text-sm text-foreground placeholder:text-muted-foreground focus:border-primary focus:outline-none focus:ring-1 focus:ring-primary"
              />
              <p className="mt-1 text-xs text-muted-foreground">
                Get your key at{" "}
                <a href="https://ai.google.dev/" target="_blank" rel="noopener noreferrer" className="text-primary hover:underline">
                  ai.google.dev
                </a>
              </p>
            </div>

            <div>
              <label className="mb-1.5 block text-sm font-medium text-foreground">HuggingFace API Key</label>
              <input
                type="password"
                value={hfKey}
                onChange={(e) => setHfKey(e.target.value)}
                placeholder="Enter your HuggingFace API key (optional)"
                className="w-full rounded-lg border border-border bg-secondary/50 px-4 py-3 text-sm text-foreground placeholder:text-muted-foreground focus:border-primary focus:outline-none focus:ring-1 focus:ring-primary"
              />
              <p className="mt-1 text-xs text-muted-foreground">
                Optional — Used for Stable Diffusion image generation
              </p>
            </div>
          </div>

          <div className="mt-6 flex items-center gap-3">
            <button
              onClick={handleSave}
              className="inline-flex items-center gap-2 rounded-lg bg-primary px-5 py-2.5 text-sm font-semibold text-primary-foreground transition-all hover:opacity-90 glow-hover"
            >
              {saved ? <Check className="h-4 w-4" /> : <Save className="h-4 w-4" />}
              {saved ? "Saved!" : "Save Settings"}
            </button>
          </div>
        </div>

        {/* Info card */}
        <div className="mt-6 glass-card rounded-xl p-5">
          <h3 className="mb-2 text-sm font-semibold text-foreground">Security Note</h3>
          <p className="text-xs leading-relaxed text-muted-foreground">
            Your API keys are stored securely in your browser's local storage and are never sent to our servers.
            They are only used to make direct API calls to Google and HuggingFace services from your browser.
          </p>
        </div>
      </div>
    </div>
  );
};

export default SettingsPage;
