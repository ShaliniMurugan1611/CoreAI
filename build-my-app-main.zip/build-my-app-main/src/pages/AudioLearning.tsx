import { useState } from "react";
import { Headphones, Loader2, Play, Pause, Volume2 } from "lucide-react";

const AudioLearning = () => {
  const [topic, setTopic] = useState("");
  const [loading, setLoading] = useState(false);
  const [generated, setGenerated] = useState(false);
  const [playing, setPlaying] = useState(false);

  const handleGenerate = () => {
    if (!topic.trim()) return;
    setLoading(true);
    setTimeout(() => {
      setGenerated(true);
      setLoading(false);
    }, 2000);
  };

  return (
    <div className="p-6 lg:p-10">
      <div className="mx-auto max-w-4xl">
        <div className="mb-8">
          <div className="mb-2 inline-flex items-center gap-2 rounded-full bg-success/10 px-3 py-1 text-xs font-medium text-success">
            <Headphones className="h-3.5 w-3.5" />
            Audio Learning
          </div>
          <h1 className="text-3xl font-bold text-foreground">Audio Lesson Generator</h1>
          <p className="mt-2 text-muted-foreground">
            Convert ML concepts into audio lessons for on-the-go learning
          </p>
        </div>

        <div className="glass-card mb-8 rounded-xl p-6">
          <label className="mb-2 block text-sm font-medium text-foreground">ML Topic</label>
          <input
            type="text"
            value={topic}
            onChange={(e) => setTopic(e.target.value)}
            placeholder="e.g., Gradient Descent Optimization"
            className="mb-6 w-full rounded-lg border border-border bg-secondary/50 px-4 py-3 text-sm text-foreground placeholder:text-muted-foreground focus:border-primary focus:outline-none focus:ring-1 focus:ring-primary"
          />

          <button
            onClick={handleGenerate}
            disabled={!topic.trim() || loading}
            className="inline-flex items-center gap-2 rounded-lg bg-primary px-6 py-3 text-sm font-semibold text-primary-foreground transition-all hover:opacity-90 disabled:opacity-50 glow-hover"
          >
            {loading ? <Loader2 className="h-4 w-4 animate-spin" /> : <Headphones className="h-4 w-4" />}
            {loading ? "Generating Audio..." : "Generate Audio Lesson"}
          </button>
        </div>

        {generated && (
          <div className="glass-card rounded-xl p-6">
            <h2 className="mb-4 text-lg font-semibold text-foreground">Generated Audio Lesson</h2>
            
            {/* Audio Player UI */}
            <div className="rounded-xl bg-secondary/50 p-6">
              <div className="mb-4 flex items-center gap-4">
                <button
                  onClick={() => setPlaying(!playing)}
                  className="flex h-14 w-14 items-center justify-center rounded-full bg-primary text-primary-foreground transition-all hover:opacity-90 glow-hover"
                >
                  {playing ? <Pause className="h-6 w-6" /> : <Play className="h-6 w-6 ml-0.5" />}
                </button>
                <div className="flex-1">
                  <p className="text-sm font-medium text-foreground">{topic || "ML Topic"}</p>
                  <p className="text-xs text-muted-foreground">AI Generated • 4:32</p>
                </div>
                <Volume2 className="h-5 w-5 text-muted-foreground" />
              </div>

              {/* Progress bar */}
              <div className="relative h-1.5 w-full rounded-full bg-muted">
                <div className="absolute left-0 top-0 h-full w-1/3 rounded-full bg-primary transition-all" />
              </div>
              <div className="mt-2 flex justify-between text-xs text-muted-foreground">
                <span>1:28</span>
                <span>4:32</span>
              </div>
            </div>

            {/* Script Preview */}
            <div className="mt-6">
              <h3 className="mb-2 text-sm font-medium text-foreground">Audio Script Preview</h3>
              <div className="rounded-lg bg-secondary/50 p-4 text-sm leading-relaxed text-muted-foreground">
                "Welcome to today's lesson on {topic || "this ML concept"}. Let's break this down into easy-to-understand concepts. 
                We'll start with the fundamentals and gradually build up to more advanced ideas. 
                By the end of this lesson, you'll have a solid understanding of how this concept works in practice..."
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default AudioLearning;
