import { Link } from "react-router-dom";
import {
  FileText,
  Code,
  Headphones,
  Image,
  ArrowRight,
  Sparkles,
  Zap,
  BookOpen,
  Brain,
} from "lucide-react";

const features = [
  {
    icon: FileText,
    title: "Text Explanations",
    description: "Get structured, detailed explanations of any ML concept with adjustable depth levels.",
    path: "/text-explanation",
    color: "text-primary",
    bgColor: "bg-primary/10",
  },
  {
    icon: Code,
    title: "Code Generation",
    description: "Generate production-ready Python code with comments, dependency detection, and execution guides.",
    path: "/code-generation",
    color: "text-accent",
    bgColor: "bg-accent/10",
  },
  {
    icon: Headphones,
    title: "Audio Learning",
    description: "Convert ML concepts into audio lessons for on-the-go learning and accessibility.",
    path: "/audio-learning",
    color: "text-success",
    bgColor: "bg-success/10",
  },
  {
    icon: Image,
    title: "Image Visualization",
    description: "Generate educational diagrams, architecture visualizations, and concept illustrations.",
    path: "/image-visualization",
    color: "text-warning",
    bgColor: "bg-warning/10",
  },
];

const stats = [
  { label: "Learning Modalities", value: "4+" },
  { label: "AI Model", value: "Gemini 2.0" },
  { label: "Depth Levels", value: "3" },
  { label: "Export Formats", value: "5+" },
];

const Index = () => {
  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <section className="relative overflow-hidden px-6 py-20 lg:px-12 lg:py-28">
        {/* Background effects */}
        <div className="absolute inset-0 overflow-hidden">
          <div className="absolute -top-40 -right-40 h-80 w-80 rounded-full bg-primary/5 blur-3xl animate-pulse-glow" />
          <div className="absolute -bottom-40 -left-40 h-80 w-80 rounded-full bg-accent/5 blur-3xl animate-pulse-glow" style={{ animationDelay: '1.5s' }} />
        </div>

        <div className="relative mx-auto max-w-4xl text-center">
          <div className="mb-6 inline-flex items-center gap-2 rounded-full border border-primary/20 bg-primary/5 px-4 py-1.5 text-xs font-medium text-primary">
            <Sparkles className="h-3.5 w-3.5" />
            AI-Powered ML Education Platform
          </div>

          <h1 className="mb-6 text-4xl font-bold leading-tight tracking-tight text-foreground sm:text-5xl lg:text-6xl">
            Master Machine Learning{" "}
            <span className="gradient-text">Concepts Effortlessly</span>
          </h1>

          <p className="mx-auto mb-10 max-w-2xl text-lg text-muted-foreground">
            GyanGuru transforms how you learn AI & ML through interactive text explanations,
            code generation, audio lessons, and visual diagrams — all powered by Google Gemini AI.
          </p>

          <div className="flex flex-wrap items-center justify-center gap-4">
            <Link
              to="/text-explanation"
              className="inline-flex items-center gap-2 rounded-lg bg-primary px-6 py-3 text-sm font-semibold text-primary-foreground transition-all hover:opacity-90 glow-hover"
            >
              Start Learning
              <ArrowRight className="h-4 w-4" />
            </Link>
            <Link
              to="/about"
              className="inline-flex items-center gap-2 rounded-lg border border-border bg-secondary px-6 py-3 text-sm font-semibold text-secondary-foreground transition-all hover:bg-muted"
            >
              Learn More
            </Link>
          </div>
        </div>
      </section>

      {/* Stats */}
      <section className="border-y border-border bg-secondary/30 px-6 py-8">
        <div className="mx-auto flex max-w-4xl flex-wrap items-center justify-around gap-8">
          {stats.map((stat) => (
            <div key={stat.label} className="text-center">
              <p className="text-2xl font-bold text-foreground">{stat.value}</p>
              <p className="text-xs text-muted-foreground">{stat.label}</p>
            </div>
          ))}
        </div>
      </section>

      {/* Features */}
      <section className="px-6 py-20 lg:px-12">
        <div className="mx-auto max-w-5xl">
          <div className="mb-12 text-center">
            <h2 className="mb-3 text-3xl font-bold text-foreground">Multi-Modal Learning</h2>
            <p className="text-muted-foreground">Choose the learning style that works best for you</p>
          </div>

          <div className="grid gap-6 sm:grid-cols-2">
            {features.map((feature) => (
              <Link
                key={feature.path}
                to={feature.path}
                className="glass-card group rounded-xl p-6 transition-all duration-300 hover:border-primary/30 glow-hover"
              >
                <div className={`mb-4 inline-flex rounded-lg p-2.5 ${feature.bgColor}`}>
                  <feature.icon className={`h-5 w-5 ${feature.color}`} />
                </div>
                <h3 className="mb-2 text-lg font-semibold text-foreground group-hover:text-primary transition-colors">
                  {feature.title}
                </h3>
                <p className="text-sm text-muted-foreground">{feature.description}</p>
                <div className="mt-4 flex items-center gap-1 text-xs font-medium text-primary opacity-0 transition-opacity group-hover:opacity-100">
                  Explore <ArrowRight className="h-3 w-3" />
                </div>
              </Link>
            ))}
          </div>
        </div>
      </section>

      {/* How it works */}
      <section className="border-t border-border bg-secondary/20 px-6 py-20 lg:px-12">
        <div className="mx-auto max-w-4xl">
          <div className="mb-12 text-center">
            <h2 className="mb-3 text-3xl font-bold text-foreground">How It Works</h2>
            <p className="text-muted-foreground">Three simple steps to accelerate your ML learning</p>
          </div>

          <div className="grid gap-8 sm:grid-cols-3">
            {[
              { icon: BookOpen, step: "01", title: "Choose Your Topic", desc: "Enter any AI/ML concept you want to learn about" },
              { icon: Brain, step: "02", title: "Select Modality", desc: "Pick text, code, audio, or visual learning mode" },
              { icon: Zap, step: "03", title: "Get AI Content", desc: "Receive personalized, comprehensive learning materials" },
            ].map((item) => (
              <div key={item.step} className="text-center">
                <div className="mx-auto mb-4 flex h-12 w-12 items-center justify-center rounded-full border border-primary/20 bg-primary/5">
                  <item.icon className="h-5 w-5 text-primary" />
                </div>
                <p className="mb-1 text-xs font-bold uppercase tracking-wider text-primary">{item.step}</p>
                <h3 className="mb-2 text-base font-semibold text-foreground">{item.title}</h3>
                <p className="text-sm text-muted-foreground">{item.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
};

export default Index;
