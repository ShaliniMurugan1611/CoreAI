import { useState } from "react";
import { FileText, Loader2, Copy, Check } from "lucide-react";

const depthOptions = ["Brief", "Detailed", "Comprehensive"];

const sampleResponse = `LEARNING OBJECTIVE
Understand the fundamental concept of backpropagation in neural networks, including its mathematical foundations and practical significance.

WHAT IS BACKPROPAGATION?
Backpropagation (backward propagation of errors) is the primary algorithm used for training artificial neural networks. It calculates the gradient of the loss function with respect to each weight in the network by applying the chain rule of calculus, propagating the error backward from the output layer to the input layer.

THE MATHEMATICS BEHIND IT
The algorithm works in two phases:

1. Forward Pass: Input data flows through the network, layer by layer, producing an output prediction.

2. Backward Pass: The error (difference between predicted and actual output) is calculated, and gradients are computed for each weight using the chain rule.

The weight update rule follows:
w_new = w_old - learning_rate × (∂Loss/∂w)

KEY COMPONENTS
- Loss Function: Measures prediction error (MSE, Cross-Entropy)
- Chain Rule: Enables gradient computation through composed functions
- Learning Rate: Controls step size during weight updates
- Gradient Descent: Optimization algorithm that uses computed gradients

PRACTICAL APPLICATIONS
Backpropagation is used in virtually every deep learning application including image recognition, natural language processing, autonomous vehicles, and recommendation systems.`;

const TextExplanation = () => {
  const [topic, setTopic] = useState("");
  const [depth, setDepth] = useState("Detailed");
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState("");
  const [copied, setCopied] = useState(false);

  const handleGenerate = () => {
    if (!topic.trim()) return;
    setLoading(true);
    setTimeout(() => {
      setResult(sampleResponse);
      setLoading(false);
    }, 2000);
  };

  const handleCopy = () => {
    navigator.clipboard.writeText(result);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="p-6 lg:p-10">
      <div className="mx-auto max-w-4xl">
        <div className="mb-8">
          <div className="mb-2 inline-flex items-center gap-2 rounded-full bg-primary/10 px-3 py-1 text-xs font-medium text-primary">
            <FileText className="h-3.5 w-3.5" />
            Text Explanation
          </div>
          <h1 className="text-3xl font-bold text-foreground">AI-Powered Explanations</h1>
          <p className="mt-2 text-muted-foreground">
            Get structured, detailed explanations of any ML concept
          </p>
        </div>

        {/* Input */}
        <div className="glass-card mb-8 rounded-xl p-6">
          <label className="mb-2 block text-sm font-medium text-foreground">ML Topic</label>
          <input
            type="text"
            value={topic}
            onChange={(e) => setTopic(e.target.value)}
            placeholder="e.g., Backpropagation in Neural Networks"
            className="mb-4 w-full rounded-lg border border-border bg-secondary/50 px-4 py-3 text-sm text-foreground placeholder:text-muted-foreground focus:border-primary focus:outline-none focus:ring-1 focus:ring-primary"
          />

          <label className="mb-2 block text-sm font-medium text-foreground">Depth Level</label>
          <div className="mb-6 flex gap-2">
            {depthOptions.map((opt) => (
              <button
                key={opt}
                onClick={() => setDepth(opt)}
                className={`rounded-lg px-4 py-2 text-sm font-medium transition-all ${
                  depth === opt
                    ? "bg-primary text-primary-foreground"
                    : "bg-secondary text-secondary-foreground hover:bg-muted"
                }`}
              >
                {opt}
              </button>
            ))}
          </div>

          <button
            onClick={handleGenerate}
            disabled={!topic.trim() || loading}
            className="inline-flex items-center gap-2 rounded-lg bg-primary px-6 py-3 text-sm font-semibold text-primary-foreground transition-all hover:opacity-90 disabled:opacity-50 glow-hover"
          >
            {loading ? <Loader2 className="h-4 w-4 animate-spin" /> : <FileText className="h-4 w-4" />}
            {loading ? "Generating..." : "Generate Explanation"}
          </button>
        </div>

        {/* Result */}
        {result && (
          <div className="glass-card rounded-xl p-6">
            <div className="mb-4 flex items-center justify-between">
              <h2 className="text-lg font-semibold text-foreground">Generated Explanation</h2>
              <button
                onClick={handleCopy}
                className="inline-flex items-center gap-1.5 rounded-lg bg-secondary px-3 py-1.5 text-xs font-medium text-secondary-foreground hover:bg-muted"
              >
                {copied ? <Check className="h-3.5 w-3.5" /> : <Copy className="h-3.5 w-3.5" />}
                {copied ? "Copied" : "Copy"}
              </button>
            </div>
            <div className="whitespace-pre-wrap rounded-lg bg-secondary/50 p-5 text-sm leading-relaxed text-foreground/90">
              {result}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default TextExplanation;
